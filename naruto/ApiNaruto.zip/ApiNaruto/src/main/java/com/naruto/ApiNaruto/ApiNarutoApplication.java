package com.naruto.ApiNaruto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiNarutoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiNarutoApplication.class, args);
	}

}
